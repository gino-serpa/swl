from setuptools import setup

setup(name='swl',
      version='0.1',
      description='functions to deal with scielo and wos ',
      url='',
      author='sino serpa',
      author_email='gino.serpa@gmail.com',
      license='MIT',
      packages=['swl'],
      zip_safe=False)
